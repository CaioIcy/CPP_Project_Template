This README will be packed with CPack.
